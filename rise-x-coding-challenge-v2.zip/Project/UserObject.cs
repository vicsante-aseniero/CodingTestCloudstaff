using System;

namespace Diana.Code.Challenge
{
    public class UserObject
    {
        public Guid Id { get; set; }
        string Name { get; set; }
    }
}
